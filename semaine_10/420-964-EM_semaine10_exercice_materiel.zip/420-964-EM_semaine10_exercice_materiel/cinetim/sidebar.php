<aside class="panel">
    <button class="panel__toggle" type="button" data-panel-toggle></button>
    <div class="panel__content">
        <h3>Tous nos films.. <span>dans le désordre</span></h3>

        <ol>
            <li>Titre film 2</li>
            <li>Titre film 1</li>
            <li>Titre film 10</li>
            <li>Titre film 7</li>
            <li>Titre film 5</li>
            <li>Titre film 4</li>
            <li>Titre film 8</li>
            <li>Titre film 3</li>
            <li>Titre film 9</li>
        </ol>
    </div>
</aside>
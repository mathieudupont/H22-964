<?php

// charger les styles et les scripts
function cinetim_theme_name_scripts() {
    wp_enqueue_style( 'style-name0', 'https://fonts.googleapis.com/css?family=Montserrat:400,700,900&display=swap' );
    wp_enqueue_style( 'style-name', get_template_directory_uri() . '/assets/css/style.css' );
    wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/script.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'cinetim_theme_name_scripts' );

// resumes de 10 mots
function new_excerpt_length($length) {
    return 10;
}
add_filter('excerpt_length', 'new_excerpt_length');

// creer CPT movies
function cw5_movies() {
    $labels = array(
        'name'                  => _x( 'Films', 'Post Type General Name', 'cw5_movies' ),
        'singular_name'         => _x( 'Film', 'Post Type Singular Name', 'cw5_movies' ),
        'menu_name'             => __( 'Films', 'cw5_movies' ),
        'name_admin_bar'        => __( 'Post Type', 'cw5_movies' ),
        'archives'              => __( 'Item Archives', 'cw5_movies' ),
        'attributes'            => __( 'Item Attributes', 'cw5_movies' ),
        'parent_item_colon'     => __( 'Parent Item:', 'cw5_movies' ),
        'all_items'             => __( 'Tous les films', 'cw5_movies' ),
        'add_new_item'          => __( 'Ajouter un film', 'cw5_movies' ),
        'add_new'               => __( 'Ajouter un film', 'cw5_movies' ),
        'new_item'              => __( 'Nouveau film', 'cw5_movies' ),
        'edit_item'             => __( 'Éditer le film', 'cw5_movies' ),
        'update_item'           => __( 'MAJ le film', 'cw5_movies' ),
        'view_item'             => __( 'View Item', 'cw5_movies' ),
        'view_items'            => __( 'View Items', 'cw5_movies' ),
        'search_items'          => __( 'Search Item', 'cw5_movies' ),
        'not_found'             => __( 'Not found', 'cw5_movies' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'cw5_movies' ),
        'featured_image'        => __( 'Featured Image', 'cw5_movies' ),
        'set_featured_image'    => __( 'Set featured image', 'cw5_movies' ),
        'remove_featured_image' => __( 'Remove featured image', 'cw5_movies' ),
        'use_featured_image'    => __( 'Use as featured image', 'cw5_movies' ),
        'insert_into_item'      => __( 'Insert into item', 'cw5_movies' ),
        'uploaded_to_this_item' => __( 'Uploaded to this item', 'cw5_movies' ),
        'items_list'            => __( 'Items list', 'cw5_movies' ),
        'items_list_navigation' => __( 'Items list navigation', 'cw5_movies' ),
        'filter_items_list'     => __( 'Filter items list', 'cw5_movies' ),
    );
    $args = array(
        'label'                 => __( 'Film', 'cw5_movies' ),
        'description'           => __( 'Films', 'cw5_movies' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'thumbnail' ),
        'taxonomies'            => array( 'category', 'post_tag' ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'menu_icon'             => 'dashicons-editor-video',
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'page',
        'show_in_rest'          => true,
    );
    register_post_type( 'movies', $args );
}
add_action( 'init', 'cw5_movies', 0 );

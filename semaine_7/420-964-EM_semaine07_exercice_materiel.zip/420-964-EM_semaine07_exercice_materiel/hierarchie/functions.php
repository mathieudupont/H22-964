<?php

// Enqueue theme scripts and styles.
function enqueue_style_css() {
    wp_enqueue_style( 'style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'enqueue_style_css' );

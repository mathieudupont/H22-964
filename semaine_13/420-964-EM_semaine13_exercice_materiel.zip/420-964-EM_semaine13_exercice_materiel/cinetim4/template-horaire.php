<?php
/*
Template Name: Horaire
 */
?>
<?php get_header(); ?>

    <section class="section wrap">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <h1><?php the_title(); ?></h1>
                <div class="o-typography">
                    <?php the_content(); ?>
                    <!-- on affiche les acf options générales des jours de présentation -->
                    <ul class="list-cinema">
                        <li>
                            <!-- format de date sortant directement d'un acf -->
                            Jour 1 : <?php the_field('cw4_jour_1', 'options'); ?>
                        </li>
                        <li>
                            <!-- format de date en français avec la journée -->
                            Jour 2 :
                            <?php $date = strtotime( get_field('cw4_jour_2', 'options') );?>
                            <?php echo date_i18n('l d F, Y', $date ); ?>
                        </li>
                        <li>
                            <!-- autre format de date en français sans la journée ni l'année -->
                            Jour 3 :
                            <?php $date = strtotime( get_field('cw4_jour_3', 'options') );?>
                            <?php echo date_i18n('d F', $date ); ?>
                        </li>
                    </ul>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </section>

    <!-- Jour 1 avec boucle foreach -->
    <section class="section wrap">
        <!-- Date formattée en français -->
        <?php $date = strtotime( get_field('cw4_jour_1', 'options') );?>
        <h2>À l'affiche le <?php echo date_i18n('l d F, Y', $date ); ?></h2>

        <div class="cards">

            <?php
            /* on sélectionne le cpt film dont le jour de présentation est "Jour 1" */
            $posts = get_posts(array(
                'numberposts'	=> -1,
                'post_type'		=> 'film',
                'post_status' => 'publish',
                'meta_key'		=> 'cw4_films_journee_de_presentation',
                'meta_value'	=> 'Jour 1'
            ));

            if ( $posts ):
                ?>
                <?php foreach( $posts as $post ):
                /* setup_postdata( $post );   cela associe les éléments du post */
                setup_postdata( $post );
                ?>

                <article class="card">
                    <a href="<?php the_permalink(); ?>">
                        <div class="card__media">
                            <?php the_post_thumbnail(); ?>
                        </div>
                        <div class="card__content">
                            <h2>
                                <?php the_title(); ?>
                                <span>(<?php echo get_the_date('Y'); ?>)</span>
                            </h2>
                            <?php the_excerpt(); ?>
                        </div>
                    </a>
                </article>

            <?php endforeach; ?>
                <?php wp_reset_postdata(); ?>

            <?php else : ?>
                <p>Aucune représentation pour la journée du <?php echo date_i18n('l d F, Y', $date ); ?></p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Jour 2 avec boucle while -->
    <section class="section wrap">
        <?php $date = strtotime( get_field('cw4_jour_2', 'options') );?>
        <h2>À l'affiche le <?php echo date_i18n('l d F, Y', $date ); ?></h2>

        <div class="cards">
            <?php
            /* on sélectionne le cpt film dont le jour de présentation est "Jour 2" */
            query_posts(array(
                'post_type' => 'film',
                'order' => 'ASC',
                'post_status' => 'publish',
                'showposts' => -1,
                'meta_key'		=> 'cw4_films_journee_de_presentation',
                'meta_value'	=> 'Jour 2'
            ));
            ?>

            <?php if (have_posts()) : ?>
                <?php while (have_posts()) : the_post(); ?>

                    <article class="card">
                        <a href="<?php the_permalink(); ?>">
                            <div class="card__media">
                                <?php the_post_thumbnail(); ?>
                            </div>
                            <div class="card__content">
                                <h2>
                                    <?php the_title(); ?>
                                    <span>(<?php echo get_the_date('Y'); ?>)</span>
                                </h2>
                                <?php the_excerpt(); ?>
                            </div>
                        </a>
                    </article>

                <?php endwhile; ?>

            <?php else : ?>
                <p>Aucune représentation pour la journée du <?php echo date_i18n('l d F, Y', $date ); ?></p>
            <?php endif; ?>
            <?php wp_reset_query(); ?>
        </div>
    </section>

    <!-- Jour 3 -->
    <section class="section wrap">
        <?php $date = strtotime( get_field('cw4_jour_3', 'options') );?>
        <h2>À l'affiche le <?php echo date_i18n('l, d F Y', $date ); ?></h2>

        <div class="cards">
            <?php

            /* on sélectionne le cpt film dont le jour de présentation est "Jour 3" */
            query_posts(array(
                'post_type' => 'film',
                'order' => 'ASC',
                'post_status' => 'publish',
                'showposts' => -1,
                'meta_key'		=> 'cw4_films_journee_de_presentation',
                'meta_value'	=> 'Jour 3'
            ));
            ?>

            <?php if (have_posts()) : ?>
                <?php while (have_posts()) : the_post(); ?>
                    <article class="card">
                        <a href="<?php the_permalink(); ?>">
                            <div class="card__media">
                                <?php the_post_thumbnail(); ?>
                            </div>
                            <div class="card__content">
                                <h2>
                                    <?php the_title(); ?>
                                    <span>(<?php echo get_the_date('Y'); ?>)</span>
                                </h2>
                                <?php the_excerpt(); ?>
                            </div>
                        </a>
                    </article>
                <?php endwhile; ?>

            <?php else : ?>
                <p>Aucune représentation pour la journée du <?php echo date_i18n('l d F, Y', $date ); ?></p>
            <?php endif; ?>
            <?php wp_reset_query(); ?>
        </div>

    </section>


<?php get_footer(); ?>
<?php get_header(); ?>

<?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
    <section class="hero">
        <div class="wrap">
            <div class="hero__medias">
                <div class="hero__poster">
                    <?php the_post_thumbnail(); ?>
                </div>
                <div class="hero__image">
                    <?php $image = get_field('cw4_film_image'); ?>
                    <?php if ($image): ?>
                        <img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>">
                    <?php endif ?>
                </div>
            </div>
        </div>
    </section>

    <section class="grid section wrap">
        <h1 class="grid__title">
            <?php the_title(); ?>
        </h1>
        <div class="grid__content o-typography">
            <?php the_content(); ?>
        </div>
        <div class="grid__sidebar o-typography">
            <h3>Ma note</h3>
            <p>
                <?php the_field('cw4_film_note') ?>
                ⭐
            </p>

            <?php 
                $realisateur = get_field('cw4_film_realisateur');

                if ($realisateur):
            ?>
                <h3>Réalisateur</h3>
                <p><?php echo get_the_title($realisateur->ID); ?></p>
            <?php endif ?>
            
            <h3>Date de sortie</h3>
            <p><?php the_date(); ?></p>

            <h3>Genre</h3>
            <?php $categories = array(); ?>
            <?php foreach( get_the_category() as $category ): ?>
                <?php array_push($categories, $category->name); ?>
            <?php endforeach?>
            <p><?php echo implode(', ', $categories); ?></p>
        </div>
    </section>

    <!-- SECTION ACTEURS -->
    <section class="section wrap o-typography">
        <h2>Acteurs</h2>
        <div class="cards">
            <!-- acteur -->
            <article class="card">
                <a href="#">
                    <div class="card__media">
                        <img src="<?php bloginfo('template_url'); ?>/assets/affiche.jpg" alt="Photo de l'acteur">
                    </div>
                    <div class="card__content">
                        <h2>
                            Jean-Paul Gamache
                        </h2>
                        <!-- Pas besoin de changer l'icône, vous pouvez laisser americas, même pour une actrice italienne -->
                        <i class="fas fa-globe-americas"></i>
                        <span>Canada</span>
                    </div>
                </a>
            </article>
            
            <!-- acteur -->
            <article class="card">
                <a href="#">
                    <div class="card__media">
                        <img src="<?php bloginfo('template_url'); ?>/assets/affiche.jpg" alt="Photo de l'acteur">
                    </div>
                    <div class="card__content">
                        <h2>
                            Jean-Paul Gamache
                        </h2>
                        <!-- Pas besoin de changer l'icône, vous pouvez laisser americas, même pour une actrice italienne -->
                        <i class="fas fa-globe-americas"></i>
                        <span>Canada</span>
                    </div>
                </a>
            </article>
        </div>
    </section>
    <!-- FIN SECTION ACTEURS -->


    <?php if (have_rows('cw4_film_blocs')): ?>
        <?php while (have_rows('cw4_film_blocs')) : the_row(); ?>

            <?php if (get_row_layout() == 'cw4_bloc_galerie'): ?>

                <?php if (have_rows('galerie')): ?>

                    <section class="section o-typography">
                        <h2 class="wrap">Images</h2>
                        <div class="swiper-container" data-component="galerie">
                            <div class="swiper-wrapper">

                                <?php while (have_rows('galerie')) : the_row(); ?>
                                    <div class="swiper-slide">
                                        <?php $image = get_sub_field('image'); ?>
                                        <img src="<?php echo $image['url'] ?>" alt="<?php echo $image['alt'] ?>">
                                    </div>
                                <?php endwhile; ?>

                            </div>
                            <div class="swiper-pagination"></div>
                        </div>
                    </section>
                <?php endif; ?>

            <?php elseif (get_row_layout() == 'cw4_bloc_critique'): ?>
                
                <?php if (have_rows('critique')): ?>

                    <section class="section wrap o-typography">
                        <h2>Critiques</h2>
                        <div class="grid">

                            <?php while (have_rows('critique')) : the_row(); ?>
                                <div class="col o-typography">
                                    <h3><?php the_sub_field('titre'); ?></h3>
                                    <p><?php the_sub_field('extrait'); ?></p>
                                    <p><a class="button" href="<?php the_sub_field('url'); ?>" target="_blank">Voir la critique complète</a></p>
                                </div>
                            <?php endwhile; ?>

                        </div>
                    </section>
                <?php endif; ?>

            <?php endif; ?>

        <?php endwhile; ?>
        <?php endif; ?>

    <?php endwhile; ?>
<?php endif; ?>

<?php get_footer(); ?>
class Main {
    constructor(options) {
        this.component = [];
        this.init();
    }

    init() {
        // Mini factory de component, si jamais tu vois ce commentaire,
        // poke moi sur Slack que je sache que tu l'as trouvé
        const components = document.querySelectorAll('[data-component]');
        components.forEach(component => {
            const type = component.dataset.component;
            switch(type) {
                case 'galerie':
                    const options = {
                        pagination: {
                            clickable: true,
                            el: '.swiper-pagination',
                            type: 'bullets',
                        }
                    };
                    this.component.push(new Swiper(component, options));
                    break;
            }
        })
    }
}
new Main();